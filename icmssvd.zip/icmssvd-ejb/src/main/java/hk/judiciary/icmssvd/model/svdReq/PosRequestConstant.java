package hk.judiciary.icmssvd.model.svdReq;

/**
 * 
 * @version $Revision: 2551 $ $Date: 2016-12-30 21:14:55 +0800 (Fri, 30 Dec 2016) $
 * @author $Author: vicki.huang $
 */
public class PosRequestConstant {
    public static final String TYPE_POS = "Affirmation";
    public static final String TYPE_ACIP = "Attend Court";

}
