package hk.judiciary.icmssvd.model.report.biz.dto;

public class RptSvdSerHistDTO {
	private String caseNo;
	private String regID;
	private String assignDate;
	private String result;
	private String defendantTel;
	private String processServer;
	private String remark;
	
	public String getCaseNo() {
		return caseNo;
	}
	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}
	public String getRegID() {
		return regID;
	}
	public void setRegID(String regID) {
		this.regID = regID;
	}
	public String getAssignDate() {
		return assignDate;
	}
	public void setAssignDate(String assignDate) {
		this.assignDate = assignDate;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getDefendantTel() {
		return defendantTel;
	}
	public void setDefendantTel(String defendantTel) {
		this.defendantTel = defendantTel;
	}
	public String getProcessServer() {
		return processServer;
	}
	public void setProcessServer(String processServer) {
		this.processServer = processServer;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	
	
}
