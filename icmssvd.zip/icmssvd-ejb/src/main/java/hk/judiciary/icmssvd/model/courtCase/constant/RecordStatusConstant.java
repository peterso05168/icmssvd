package hk.judiciary.icmssvd.model.courtCase.constant;

public enum RecordStatusConstant {
	NEW ("I"),
	UPDATE ("U"),
	DELETE ("D"),
	NONE ("N");
	
	private String code;
	
	private RecordStatusConstant(String code) {
		this.code = code;
	}
	public String getCode() {
		return code;
	}
}
