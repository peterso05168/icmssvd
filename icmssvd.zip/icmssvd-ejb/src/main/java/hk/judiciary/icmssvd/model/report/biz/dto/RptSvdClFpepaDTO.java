package hk.judiciary.icmssvd.model.report.biz.dto;

public class RptSvdClFpepaDTO {
	
	private String courtName;
	private String prosecutionDept;
	private String caseNo;
	private String caseInitiationDate;
	private String exParteHearingDate;
	private String totalNoOfCase;

	public String getCourtName() {
		return courtName;
	}

	public void setCourtName(String courtName) {
		this.courtName = courtName;
	}

	public String getProsecutionDept() {
		return prosecutionDept;
	}

	public void setProsecutionDept(String prosecutionDept) {
		this.prosecutionDept = prosecutionDept;
	}

	public String getCaseNo() {
		return caseNo;
	}

	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}

	public String getCaseInitiationDate() {
		return caseInitiationDate;
	}

	public void setCaseInitiationDate(String caseInitiationDate) {
		this.caseInitiationDate = caseInitiationDate;
	}

	public String getExParteHearingDate() {
		return exParteHearingDate;
	}

	public void setExParteHearingDate(String exParteHearingDate) {
		this.exParteHearingDate = exParteHearingDate;
	}

	public String getTotalNoOfCase() {
		return totalNoOfCase;
	}

	public void setTotalNoOfCase(String totalNoOfCase) {
		this.totalNoOfCase = totalNoOfCase;
	}
}
