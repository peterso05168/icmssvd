package hk.judiciary.icmssvd.model.svdReq.dao;

import hk.judiciary.icms.model.dao.entity.ReqsRslt;
import hk.judiciary.icmssvd.model.BaseDAO;

/**
 * 
 * @version $Revision: 2551 $ $Date: 2016-12-30 21:14:55 +0800 (週五, 30 十二月 2016) $
 * @author $Author: vicki.huang $
 */
public class ReqsRsltDAO extends BaseDAO<ReqsRslt> {
    public static final String REQS_RSLT_DAO = "reqsRsltDAO";
}
