package hk.judiciary.icmssvd.model.svdReq;

/**
 * 
 * @version $Revision: 2551 $ $Date: 2016-12-30 21:14:55 +0800 (Fri, 30 Dec 2016) $
 * @author $Author: vicki.huang $
 */
public class HearingConstant {
    public static final String HEARING_RESULT_RESERVICE = "RES";// Re-service of Summons 
    public static final String HEARING_RESULT_PROOF_OF_SERVICE = "POS";// Proof of service 
}
