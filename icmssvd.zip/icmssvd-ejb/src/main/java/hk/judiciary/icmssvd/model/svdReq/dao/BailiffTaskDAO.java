package hk.judiciary.icmssvd.model.svdReq.dao;

import hk.judiciary.icms.model.dao.entity.BlfTask;
import hk.judiciary.icmssvd.model.BaseDAO;

/**
 * 
 * @version $Revision: 7895 $ $Date: 2017-07-10 10:36:55 +0800 (Mon, 10 Jul 2017) $
 * @author $Author: mtse $
 */
public class BailiffTaskDAO extends BaseDAO<BlfTask> {
    public static final String BAILIFF_TASK_DAO = "bailiffTaskDAO";

}
