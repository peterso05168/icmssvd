package hk.judiciary.icmssvd.model.courtCase.biz.dto.criteria;

public class HrnSchdRetrieveCriteriaDTO extends CommonRetrieveCriteriaDTO {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer caseId;
	private String status;
	public Integer getCaseId() {
		return caseId;
	}
	public void setCaseId(Integer caseId) {
		this.caseId = caseId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
