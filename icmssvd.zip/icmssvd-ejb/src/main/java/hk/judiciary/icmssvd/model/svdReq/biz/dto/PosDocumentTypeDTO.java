package hk.judiciary.icmssvd.model.svdReq.biz.dto;

import hk.judiciary.icmssvd.model.BaseDTO;

/**
 * 
 * @version $Revision: 2551 $ $Date: 2016-12-30 21:14:55 +0800 (Fri, 30 Dec 2016) $
 * @author $Author: vicki.huang $
 */
public class PosDocumentTypeDTO extends BaseDTO {
    private static final long serialVersionUID = 1L;
    private Integer posDocumentTypeId;
    private String posDocumentTypeName;
    private String posDocumentTypeCode;

    public Integer getPosDocumentTypeId() {
        return posDocumentTypeId;
    }

    public void setPosDocumentTypeId(Integer posDocumentTypeId) {
        this.posDocumentTypeId = posDocumentTypeId;
    }

    public String getPosDocumentTypeName() {
        return posDocumentTypeName;
    }
    
    public void setPosDocumentTypeName(String posDocumentTypeName) {
        this.posDocumentTypeName = posDocumentTypeName;
    }

    public String getPosDocumentTypeCode() {
        return posDocumentTypeCode;
    }

    public void setPosDocumentTypeCode(String posDocumentTypeCode) {
        this.posDocumentTypeCode = posDocumentTypeCode;
    }

    @Override
    public String toString() {
        return "PosDocumentTypeDTO [posDocumentTypeId=" + posDocumentTypeId
                + ", posDocumentTypeName=" + posDocumentTypeName + ", posDocumentTypeCode="
                + posDocumentTypeCode + "]";
    }

}
