package hk.judiciary.icmssvd.model.svdReq.biz.dto;

import hk.judiciary.icmssvd.model.BaseDTO;

/**
 * 
 * @version $Revision: 2551 $ $Date: 2016-12-30 21:14:55 +0800 (Fri, 30 Dec 2016) $
 * @author $Author: vicki.huang $
 */
public class IntlUserAcDTO extends BaseDTO {
    private static final long serialVersionUID = 1L;
    private Integer intlUserAcId;
    private String loginName;
    private String englishSurname;
    private String englishGivenName;
    private String chineseSurname;
    private String chineseGivenName;

    public Integer getIntlUserAcId() {
        return intlUserAcId;
    }

    public void setIntlUserAcId(Integer intlUserAcId) {
        this.intlUserAcId = intlUserAcId;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getEnglishSurname() {
        return englishSurname;
    }

    public void setEnglishSurname(String englishSurname) {
        this.englishSurname = englishSurname;
    }

    public String getEnglishGivenName() {
        return englishGivenName;
    }

    public void setEnglishGivenName(String englishGivenName) {
        this.englishGivenName = englishGivenName;
    }

    public String getChineseSurname() {
        return chineseSurname;
    }

    public void setChineseSurname(String chineseSurname) {
        this.chineseSurname = chineseSurname;
    }

    public String getChineseGivenName() {
        return chineseGivenName;
    }

    public void setChineseGivenName(String chineseGivenName) {
        this.chineseGivenName = chineseGivenName;
    }

    @Override
    public String toString() {
        return "IntlUserAcDTO [intlUserAcId=" + intlUserAcId + ", loginName=" + loginName
                + ", englishSurname=" + englishSurname + ", englishGivenName=" + englishGivenName
                + ", chineseSurname=" + chineseSurname + ", chineseGivenName=" + chineseGivenName
                + "]";
    }

}
