package hk.judiciary.icmssvd.model.report.biz.dto;

import java.util.List;

import hk.judiciary.fmk.model.report.biz.dto.ReportRequestData;

public class RptSvdCertPosBkDTO implements ReportRequestData {
	private String courtNameEng;
	private String courtTel;
	private List<RptSvdCertPosBkSubDTO> arrayList;

	public List<RptSvdCertPosBkSubDTO> getArrayList() {
		return arrayList;
	}

	public void setArrayList(List<RptSvdCertPosBkSubDTO> arrayList) {
		this.arrayList = arrayList;
	}

	public String getCourtNameEng() {
		return courtNameEng;
	}

	public void setCourtNameEng(String courtNameEng) {
		this.courtNameEng = courtNameEng;
	}

	public String getCourtTel() {
		return courtTel;
	}

	public void setCourtTel(String courtTel) {
		this.courtTel = courtTel;
	}


}
