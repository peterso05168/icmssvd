package hk.judiciary.icmssvd.model.svdReq;

/**
 * 
 * @version $Revision: 2551 $ $Date: 2016-12-30 21:14:55 +0800 (Fri, 30 Dec 2016) $
 * @author $Author: vicki.huang $
 */
public class DocumentConstant {
    public static final String DOCUMENT_TYPE_DSD = "DSD"; // Departmental Summons (Form 1) - Defendant Copy
    public static final String DOCUMENT_TYPE_DSC = "DSC"; // Departmental Summons (Form 1) - Court Copy
    public static final String DOCUMENT_TYPE_DOPSD = "DOPSD"; // Driving Offence Point (DOP) Summons - Defendant Copy
    public static final String DOCUMENT_TYPE_DOPSC = "DOPSC"; // Driving Offence Point (DOP) Summons - Court Copy
    public static final String DOCUMENT_TYPE_FPSD = "FPSD"; // FP Summons - Defendant Copy
    public static final String DOCUMENT_TYPE_FPSC = "FPSC"; // FP Summons - Court Copy
    public static final String DOCUMENT_TYPE_PGBL = "PGBL"; // PGBL
}
