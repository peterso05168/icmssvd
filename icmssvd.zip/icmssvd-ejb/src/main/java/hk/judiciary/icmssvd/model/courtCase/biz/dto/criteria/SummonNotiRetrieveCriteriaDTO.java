package hk.judiciary.icmssvd.model.courtCase.biz.dto.criteria;

public class SummonNotiRetrieveCriteriaDTO extends CommonRetrieveCriteriaDTO {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer caseId;
	public Integer getCaseId() {
		return caseId;
	}
	public void setCaseId(Integer caseId) {
		this.caseId = caseId;
	}
}
