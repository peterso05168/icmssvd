package hk.judiciary.icmssvd.model.courtCase.exception;

import hk.judiciary.icmssvd.model.courtCase.constant.CriminalCaseException;

public class CriminalServerValidationException extends Exception {
	private static final long serialVersionUID = 1L;

	private CriminalCaseException criminalCaseException;
	private String exceptionDetails;
	
	public CriminalCaseException getCriminalCaseException() {
		return criminalCaseException;
	}
	public void setCriminalCaseException(CriminalCaseException criminalCaseException) {
		this.criminalCaseException = criminalCaseException;
	}
	public String getExceptionDetails() {
		return exceptionDetails;
	}
	public void setExceptionDetails(String exceptionDetails) {
		this.exceptionDetails = exceptionDetails;
	}
	
}
