package hk.judiciary.icmssvd.model.report.biz.dto;

import hk.judiciary.fmk.model.report.biz.dto.ReportRequestData;

public class RptSvdDSub1DTO implements ReportRequestData {
	private String offenceId;
	private String offenceDate;
	private String punishmentEffDate;
	private String pointDeduction;

	public String getOffenceId() {
		return offenceId;
	}

	public void setOffenceId(String offenceId) {
		this.offenceId = offenceId;
	}

	public String getOffenceDate() {
		return offenceDate;
	}

	public void setOffenceDate(String offenceDate) {
		this.offenceDate = offenceDate;
	}

	public String getPunishmentEffDate() {
		return punishmentEffDate;
	}

	public void setPunishmentEffDate(String punishmentEffDate) {
		this.punishmentEffDate = punishmentEffDate;
	}

	public String getPointDeduction() {
		return pointDeduction;
	}

	public void setPointDeduction(String pointDeduction) {
		this.pointDeduction = pointDeduction;
	}
}
