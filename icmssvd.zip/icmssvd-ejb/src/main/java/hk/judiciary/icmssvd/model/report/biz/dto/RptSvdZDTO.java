package hk.judiciary.icmssvd.model.report.biz.dto;

public class RptSvdZDTO {
	private String langType;
	private String formName1;
	private String formName2;
	private String caseNo;
	private String writNo;
	private String drnNo;
	private String courtName;
	private String courtAddress;
	private String defendantName;
	private String defendantAddress1;
	private String defendantAddress2;
	private String defendantAddress3;
	private String defendantGender;
	private String defendantAge;
	private String pdRefNo;
	private String chargeParticular;
	private String contraryToLaw;
	private String Informant;
	private String dateOfHearing;
	private String timeOfHearing;
	private String courtRoomOfHearing;
	private String courtOfHearing;
	private String venueOfHearing;
	private String addressOfHearing;
	private String magistrateName;
	private String issueDate;
	private String remarks;
	private String templateNo;

	public String getLangType() {
		return langType;
	}

	public void setLangType(String langType) {
		this.langType = langType;
	}

	public String getFormName1() {
		return formName1;
	}

	public void setFormName1(String formName1) {
		this.formName1 = formName1;
	}

	public String getFormName2() {
		return formName2;
	}

	public void setFormName2(String formName2) {
		this.formName2 = formName2;
	}

	public String getCaseNo() {
		return caseNo;
	}

	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}

	public String getWritNo() {
		return writNo;
	}

	public void setWritNo(String writNo) {
		this.writNo = writNo;
	}

	public String getDrnNo() {
		return drnNo;
	}

	public void setDrnNo(String drnNo) {
		this.drnNo = drnNo;
	}

	public String getCourtName() {
		return courtName;
	}

	public void setCourtName(String courtName) {
		this.courtName = courtName;
	}

	public String getCourtAddress() {
		return courtAddress;
	}

	public void setCourtAddress(String courtAddress) {
		this.courtAddress = courtAddress;
	}

	public String getDefendantName() {
		return defendantName;
	}

	public void setDefendantName(String defendantName) {
		this.defendantName = defendantName;
	}

	public String getDefendantAddress1() {
		return defendantAddress1;
	}

	public void setDefendantAddress1(String defendantAddress1) {
		this.defendantAddress1 = defendantAddress1;
	}

	public String getDefendantAddress2() {
		return defendantAddress2;
	}

	public void setDefendantAddress2(String defendantAddress2) {
		this.defendantAddress2 = defendantAddress2;
	}

	public String getDefendantAddress3() {
		return defendantAddress3;
	}

	public void setDefendantAddress3(String defendantAddress3) {
		this.defendantAddress3 = defendantAddress3;
	}

	public String getDefendantGender() {
		return defendantGender;
	}

	public void setDefendantGender(String defendantGender) {
		this.defendantGender = defendantGender;
	}

	public String getDefendantAge() {
		return defendantAge;
	}

	public void setDefendantAge(String defendantAge) {
		this.defendantAge = defendantAge;
	}

	public String getPdRefNo() {
		return pdRefNo;
	}

	public void setPdRefNo(String pdRefNo) {
		this.pdRefNo = pdRefNo;
	}

	public String getChargeParticular() {
		return chargeParticular;
	}

	public void setChargeParticular(String chargeParticular) {
		this.chargeParticular = chargeParticular;
	}

	public String getContraryToLaw() {
		return contraryToLaw;
	}

	public void setContraryToLaw(String contraryToLaw) {
		this.contraryToLaw = contraryToLaw;
	}

	public String getInformant() {
		return Informant;
	}

	public void setInformant(String informant) {
		Informant = informant;
	}

	public String getDateOfHearing() {
		return dateOfHearing;
	}

	public void setDateOfHearing(String dateOfHearing) {
		this.dateOfHearing = dateOfHearing;
	}

	public String getTimeOfHearing() {
		return timeOfHearing;
	}

	public void setTimeOfHearing(String timeOfHearing) {
		this.timeOfHearing = timeOfHearing;
	}

	public String getCourtRoomOfHearing() {
		return courtRoomOfHearing;
	}

	public void setCourtRoomOfHearing(String courtRoomOfHearing) {
		this.courtRoomOfHearing = courtRoomOfHearing;
	}

	public String getCourtOfHearing() {
		return courtOfHearing;
	}

	public void setCourtOfHearing(String courtOfHearing) {
		this.courtOfHearing = courtOfHearing;
	}

	public String getVenueOfHearing() {
		return venueOfHearing;
	}

	public void setVenueOfHearing(String venueOfHearing) {
		this.venueOfHearing = venueOfHearing;
	}

	public String getAddressOfHearing() {
		return addressOfHearing;
	}

	public void setAddressOfHearing(String addressOfHearing) {
		this.addressOfHearing = addressOfHearing;
	}

	public String getMagistrateName() {
		return magistrateName;
	}

	public void setMagistrateName(String magistrateName) {
		this.magistrateName = magistrateName;
	}

	public String getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(String issueDate) {
		this.issueDate = issueDate;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getTemplateNo() {
		return templateNo;
	}

	public void setTemplateNo(String templateNo) {
		this.templateNo = templateNo;
	}

}
