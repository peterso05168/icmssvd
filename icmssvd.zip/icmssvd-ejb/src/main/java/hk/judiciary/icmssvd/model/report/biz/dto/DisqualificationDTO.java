package hk.judiciary.icmssvd.model.report.biz.dto;

import hk.judiciary.fmk.model.report.biz.dto.ReportRequestData;

public class DisqualificationDTO implements ReportRequestData {
	
	private String tdRefNo;
	private String caseNo;
	private String disqualificationOrderDate;
	private String disqualificationPeriod;
    
	public String getTdRefNo() {
		return tdRefNo;
	}
	public void setTdRefNo(String tdRefNo) {
		this.tdRefNo = tdRefNo;
	}
	public String getCaseNo() {
		return caseNo;
	}
	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}
	public String getDisqualificationOrderDate() {
		return disqualificationOrderDate;
	}
	public void setDisqualificationOrderDate(String disqualificationOrderDate) {
		this.disqualificationOrderDate = disqualificationOrderDate;
	}
	public String getDisqualificationPeriod() {
		return disqualificationPeriod;
	}
	public void setDisqualificationPeriod(String disqualificationPeriod) {
		this.disqualificationPeriod = disqualificationPeriod;
	} 
}
