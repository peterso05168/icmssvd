package hk.judiciary.icmssvd.model.svdReq.biz.dto;

import hk.judiciary.icmssvd.model.BaseDTO;

/**
 * 
 * @version $Revision: 2551 $ $Date: 2016-12-30 21:14:55 +0800 (Fri, 30 Dec 2016) $
 * @author $Author: vicki.huang $
 */
public class NextHearingDateGenerationDTO extends BaseDTO {
    private static final long serialVersionUID = 1L;
    private Integer dayFromAllocation;
    private NextHearingDetailDTO nextHearingDetail;

    public Integer getDayFromAllocation() {
        return dayFromAllocation;
    }

    public void setDayFromAllocation(Integer dayFromAllocation) {
        this.dayFromAllocation = dayFromAllocation;
    }

    public NextHearingDetailDTO getNextHearingDetail() {
        return nextHearingDetail;
    }

    public void setNextHearingDetail(NextHearingDetailDTO nextHearingDetail) {
        this.nextHearingDetail = nextHearingDetail;
    }

    @Override
    public String toString() {
        return "NextHearingDateSearchDTO [dayFromAllocation=" + dayFromAllocation
                + ", nextHearingDetail=" + nextHearingDetail + "]";
    }

}
