package hk.judiciary.icmssvd.model.common.dao;

import hk.judiciary.icms.model.dao.entity.ReqsPartcpRole;
import hk.judiciary.icmssvd.model.BaseDAO;

/**
 * 
 * @version $Revision$ $Date$
 * @author $Author$
 */
public class RequestParticipantRoleDAO extends BaseDAO<ReqsPartcpRole> {
    public static final String REQUEST_PARTICIPANT_ROLE_DAO = "requestParticipantRoleDAO";

}
