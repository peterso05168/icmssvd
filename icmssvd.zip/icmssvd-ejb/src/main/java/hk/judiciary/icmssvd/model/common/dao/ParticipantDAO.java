package hk.judiciary.icmssvd.model.common.dao;

import hk.judiciary.icms.model.dao.entity.Partcp;
import hk.judiciary.icmssvd.model.BaseDAO;

/**
 * 
 * @version $Revision: 2551 $ $Date: 2016-12-30 21:14:55 +0800 (Fri, 30 Dec 2016) $
 * @author $Author: vicki.huang $
 */
public class ParticipantDAO extends BaseDAO<Partcp> {
    public static final String PARTICIPANT_DAO = "participantDAO";
}
