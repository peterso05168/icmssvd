package hk.judiciary.icmssvd.model.svdReq;

/**
 * 
 * @version $Revision: 6473 $ $Date: 2017-04-24 18:09:35 +0800 (週一, 24 四月 2017) $
 * @author $Author: vicki.huang $
 */
public class TaskConstant {
    public static final String TASK_STATUS_APPROVED = "AP";
    public static final String TASK_STATUS_CANCELLED = "CC";

}
