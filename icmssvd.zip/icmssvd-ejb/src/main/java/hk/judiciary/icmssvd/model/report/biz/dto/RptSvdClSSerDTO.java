package hk.judiciary.icmssvd.model.report.biz.dto;

import hk.judiciary.fmk.model.report.biz.dto.ReportRequestData;

public class RptSvdClSSerDTO implements ReportRequestData {

	private String timestamp;
	private String magistrateCourt;
	private String prosecutionDept;

	private String authorisationDate;
	private String batchSerialNo;
	private String defendantRefNo;
	private String caseNo;
	private String hearingDate;
	private String hearingTime;
	private String courtNo;
	private String itRequest;

	private String nameOfHolder;
	private String serviceDate;

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getMagistrateCourt() {
		return magistrateCourt;
	}

	public void setMagistrateCourt(String magistrateCourt) {
		this.magistrateCourt = magistrateCourt;
	}

	public String getProsecutionDept() {
		return prosecutionDept;
	}

	public void setProsecutionDept(String prosecutionDept) {
		this.prosecutionDept = prosecutionDept;
	}

	public String getAuthorisationDate() {
		return authorisationDate;
	}

	public void setAuthorisationDate(String authorisationDate) {
		this.authorisationDate = authorisationDate;
	}

	public String getBatchSerialNo() {
		return batchSerialNo;
	}

	public void setBatchSerialNo(String batchSerialNo) {
		this.batchSerialNo = batchSerialNo;
	}

	public String getDefendantRefNo() {
		return defendantRefNo;
	}

	public void setDefendantRefNo(String defendantRefNo) {
		this.defendantRefNo = defendantRefNo;
	}

	public String getCaseNo() {
		return caseNo;
	}

	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}

	public String getHearingDate() {
		return hearingDate;
	}

	public void setHearingDate(String hearingDate) {
		this.hearingDate = hearingDate;
	}

	public String getHearingTime() {
		return hearingTime;
	}

	public void setHearingTime(String hearingTime) {
		this.hearingTime = hearingTime;
	}

	public String getCourtNo() {
		return courtNo;
	}

	public void setCourtNo(String courtNo) {
		this.courtNo = courtNo;
	}

	public String getItRequest() {
		return itRequest;
	}

	public void setItRequest(String itRequest) {
		this.itRequest = itRequest;
	}

	public String getNameOfHolder() {
		return nameOfHolder;
	}

	public void setNameOfHolder(String nameOfHolder) {
		this.nameOfHolder = nameOfHolder;
	}

	public String getServiceDate() {
		return serviceDate;
	}

	public void setServiceDate(String serviceDate) {
		this.serviceDate = serviceDate;
	}
}
