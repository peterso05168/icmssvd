package hk.judiciary.icmssvd.model.report.biz.dto;

public class PrintCheckListAndCoverSheetResultDTO extends CommonWsDTO {
	private byte[] document;
	private String errorMessage;
	
	public byte[] getDocument() {
		return document;
	}
	public void setDocument(byte[] document) {
		this.document = document;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	
}
