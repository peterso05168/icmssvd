package hk.judiciary.icmssvd.model.common.biz.dto;

import hk.judiciary.icmssvd.model.BaseDTO;

/**
 * 
 * @version $Revision: 1052 $ $Date: 2016-11-30 16:56:51 +0800 (Wed, 30 Nov 2016) $
 * @author $Author: vicki.huang $
 */
public class BailiffStaffPostDTO extends BaseDTO {
    private static final long serialVersionUID = 1L;
    private Integer bailiffStaffPostId;
    private String bailiffStaffPostCode;
    private String bailiffStaffPostName;

    public Integer getBailiffStaffPostId() {
        return bailiffStaffPostId;
    }

    public void setBailiffStaffPostId(Integer bailiffStaffPostId) {
        this.bailiffStaffPostId = bailiffStaffPostId;
    }

    public String getBailiffStaffPostCode() {
        return bailiffStaffPostCode;
    }

    public void setBailiffStaffPostCode(String bailiffStaffPostCode) {
        this.bailiffStaffPostCode = bailiffStaffPostCode;
    }

    public String getBailiffStaffPostName() {
        return bailiffStaffPostName;
    }

    public void setBailiffStaffPostName(String bailiffStaffPostName) {
        this.bailiffStaffPostName = bailiffStaffPostName;
    }

    @Override
    public String toString() {
        return "BailiffStaffPostDTO [bailiffStaffPostId=" + bailiffStaffPostId
                + ", bailiffStaffPostCode=" + bailiffStaffPostCode + ", bailiffStaffPostName="
                + bailiffStaffPostName + "]";
    }

}
