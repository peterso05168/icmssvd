package hk.judiciary.icmssvd.model.svdReq;

/**
 * 
 * @version $Revision: 2551 $ $Date: 2016-12-30 21:14:55 +0800 (Fri, 30 Dec 2016) $
 * @author $Author: vicki.huang $
 */
public class StaffConstant {
    public static final String STAFF_POST_TYPE_CB = "CB";
    public static final String STAFF_POST_TYPE_ACB = "ACB";
    public static final String STAFF_POST_TYPE_SB = "SB";
    public static final String STAFF_POST_TYPE_BO = "BO";
    public static final String STAFF_POST_TYPE_BA = "BA";
    public static final String STAFF_POST_TYPE_CL = "CL";

}
