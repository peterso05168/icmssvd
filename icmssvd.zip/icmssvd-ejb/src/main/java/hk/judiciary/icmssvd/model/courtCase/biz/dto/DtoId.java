package hk.judiciary.icmssvd.model.courtCase.biz.dto;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface DtoId {

}
