package hk.judiciary.icmssvd.model.report.biz.dto;

public class CommonWsDTO {
	private String returnCode;
	private String returnDesc;
	public String getReturnCode() {
		return returnCode;
	}
	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}
	public String getReturnDesc() {
		return returnDesc;
	}
	public void setReturnDesc(String returnDesc) {
		this.returnDesc = returnDesc;
	}
}
