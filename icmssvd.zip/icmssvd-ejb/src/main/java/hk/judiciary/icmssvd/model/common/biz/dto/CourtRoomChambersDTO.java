package hk.judiciary.icmssvd.model.common.biz.dto;

import hk.judiciary.icmssvd.model.BaseDTO;

/**
 * 
 * @version $Revision: 43 $ $Date: 2016-09-23 12:15:30 +0800 (Fri, 23 Sep 2016) $
 * @author $Author: timhtyuen@judiciary.gov.hk $
 */
public class CourtRoomChambersDTO extends BaseDTO {
    private static final long serialVersionUID = 1L;
    private Integer courtRoomChambersId;
    private String courtRoomChambersName;
    private String floor;
    private CourtVenueDTO courtVenue;

    public Integer getCourtRoomChambersId() {
        return courtRoomChambersId;
    }

    public void setCourtRoomChambersId(Integer courtRoomChambersId) {
        this.courtRoomChambersId = courtRoomChambersId;
    }

    public String getCourtRoomChambersName() {
        return courtRoomChambersName;
    }

    public void setCourtRoomChambersName(String courtRoomChambersName) {
        this.courtRoomChambersName = courtRoomChambersName;
    }

    public String getFloor() {
        return floor;
    }

    public void setFloor(String floor) {
        this.floor = floor;
    }

    public CourtVenueDTO getCourtVenue() {
        return courtVenue;
    }

    public void setCourtVenue(CourtVenueDTO courtVenue) {
        this.courtVenue = courtVenue;
    }

    @Override
    public String toString() {
        return "CourtRoomChambersDTO [courtRoomChambersId=" + courtRoomChambersId
                + ", courtRoomChambersName=" + courtRoomChambersName + ", floor=" + floor
                + ", courtVenue=" + courtVenue + "]";
    }

}
