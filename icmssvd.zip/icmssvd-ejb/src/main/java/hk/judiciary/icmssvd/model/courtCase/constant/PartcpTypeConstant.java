package hk.judiciary.icmssvd.model.courtCase.constant;

public enum PartcpTypeConstant {
	ORGANIZATION ("O"),
	PERSON ("P");
	
	private String code;
	
	private PartcpTypeConstant(String code) {
		this.code = code;
	}
	public String getCode() {
		return code;
	}
}
