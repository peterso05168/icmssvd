package hk.judiciary.icmssvd.model.common.biz.dto;

import hk.judiciary.icmssvd.model.BaseDTO;

/**
 * 
 * @version $Revision: 1052 $ $Date: 2016-11-30 16:56:51 +0800 (週三, 30 十一月 2016) $
 * @author $Author: vicki.huang $
 */
public class RequestTypeDTO extends BaseDTO {
    private static final long serialVersionUID = 1L;
    private Integer requestTypeId;
    private String requestTypeName;

    public Integer getRequestTypeId() {
        return requestTypeId;
    }

    public void setRequestTypeId(Integer requestTypeId) {
        this.requestTypeId = requestTypeId;
    }

    public String getRequestTypeName() {
        return requestTypeName;
    }

    public void setRequestTypeName(String requestTypeName) {
        this.requestTypeName = requestTypeName;
    }

    @Override
    public String toString() {
        return "RequestTypeDTO [requestTypeId=" + requestTypeId + ", requestTypeName="
                + requestTypeName + "]";
    }

}
