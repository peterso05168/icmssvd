package hk.judiciary.icmssvd.model.courtCase.biz.dto.criteria;

import java.util.List;

import hk.judiciary.icmssvd.model.svdReq.biz.dto.FunctionDTO;

public class CaseRetrieveCriteriaDTO extends CommonRetrieveCriteriaDTO {

    private static final long serialVersionUID = 1L;
    private Integer caseId;
    private List<Integer> caseIds;
    private String caseNo;
    private FunctionDTO func;

    public List<Integer> getCaseIds() {
        return caseIds;
    }

    public void setCaseIds(List<Integer> caseIds) {
        this.caseIds = caseIds;
    }

    public Integer getCaseId() {
        return caseId;
    }

    public void setCaseId(Integer caseId) {
        this.caseId = caseId;
    }

    public String getCaseNo() {
        return caseNo;
    }

    public void setCaseNo(String caseNo) {
        this.caseNo = caseNo;
    }

    public FunctionDTO getFunc() {
        return func;
    }

    public void setFunc(FunctionDTO func) {
        this.func = func;
    }

}
