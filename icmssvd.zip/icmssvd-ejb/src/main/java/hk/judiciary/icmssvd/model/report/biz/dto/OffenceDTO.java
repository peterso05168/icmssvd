package hk.judiciary.icmssvd.model.report.biz.dto;

import hk.judiciary.fmk.model.report.biz.dto.ReportRequestData;

public class OffenceDTO implements ReportRequestData {
	
	private String offenceID;
	private String offenceDate;
	private String punishmentEffDate;
	private String pointDeduction;
    
	public String getOffenceID() {
		return offenceID;
	}
	public void setOffenceID(String offenceID) {
		this.offenceID = offenceID;
	}
	public String getOffenceDate() {
		return offenceDate;
	}
	public void setOffenceDate(String offenceDate) {
		this.offenceDate = offenceDate;
	}
	public String getPunishmentEffDate() {
		return punishmentEffDate;
	}
	public void setPunishmentEffDate(String punishmentEffDate) {
		this.punishmentEffDate = punishmentEffDate;
	}
	public String getPointDeduction() {
		return pointDeduction;
	}
	public void setPointDeduction(String pointDeduction) {
		this.pointDeduction = pointDeduction;
	}
}
